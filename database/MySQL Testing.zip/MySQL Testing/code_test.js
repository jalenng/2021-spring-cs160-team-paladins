var mysql = require('mysql');

/**
 * You will get permission denied first. To fix this, we create a new user.
 * ---------------------------------------
 * First, go to MySQL shell: 
 *      Mysql JS>  \sql
 *      Mysql SQL>  \connect root@localhost
 * Then, create a new user in the shell:
 *      CREATE USER 'newuser'@'localhost' IDENTIFIED BY 'password';
 *      GRANT ALL PRIVILEGES ON * . * TO 'newuser'@'localhost';
 *      FLUSH PRIVILEGES;
 * Finally, you can create the connection here using the new user and password on the localhost to use the correct database.
 */

// Create Connection
let con = mysql.createConnection({
    host: "localhost",
    user: "newuser",
    password: "password",
    database: "nodeTest"
});

// Connect to DB
con.connect(function(err) {
    if (err) { return console.error('error: ' + err.message) }
    console.log("Connected");

    // Show Table
    console.log("Users Table: ");
    showTable("Users");

    insertTable("Users", "('hello@gmail.com', 'pw8534')");

    console.log("Users Table: ");
    showTable("Users");


});

// Show Table
function showTable(table) {
    let sT = "SELECT * FROM " + table

    con.query(sT, function(err, result) {
        if (err) { throw err; }
        console.log(result);
    });
}

// Insert Into Table
function insertTable(table, values) {
    let query = "INSERT INTO " + table + " VALUES " + values;

    con.query(query, function(err, result) {
        if (err) { throw err; }
        console.log("Row(s) Inserted");
    });
}


